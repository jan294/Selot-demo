
const symbols = ['🍒', '🍋', '🔔', '7️⃣', '💎'];

function spin() {
    const r1 = document.getElementById('reel1');
    const r2 = document.getElementById('reel2');
    const r3 = document.getElementById('reel3');
    const msg = document.getElementById('message');

    let s1 = symbols[Math.floor(Math.random() * symbols.length)];
    let s2 = symbols[Math.floor(Math.random() * symbols.length)];
    let s3 = symbols[Math.floor(Math.random() * symbols.length)];

    r1.textContent = s1;
    r2.textContent = s2;
    r3.textContent = s3;

    if (s1 === s2 && s2 === s3) {
        msg.textContent = 'Selamat! Kamu menang!';
    } else {
        msg.textContent = 'Coba lagi!';
    }
}
